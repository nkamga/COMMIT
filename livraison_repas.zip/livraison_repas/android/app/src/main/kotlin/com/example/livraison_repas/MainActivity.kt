package com.example.livraison_repas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
