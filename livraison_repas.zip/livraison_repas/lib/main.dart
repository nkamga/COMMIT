import 'package:flutter/material.dart';

void main() {
  runApp(const MenuSection());
}

class MenuSection extends StatelessWidget {
  const MenuSection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Menu(),
    );
  }
}

class Menu extends StatefulWidget {
  const Menu({Key? key}) : super(key: key);

  @override
  State<Menu> createState() => _MenuState();
}

class _MenuState extends State<Menu> {
  var titleList = [
    "eru",
    "poisson braisé",
    "salade aux oeufs",
    "macedoine",
    "cafe",
    "le chouffleur et sa crème",
    "mousse au chocolat",
    "cocktail alcoolisé à la fraise",
    "cocktail mijito au citron menthe",
  ];

  var descList = [
    "Plat riche, nourrissant, délicieux et plein de vitamines. Repas à desguster pour le plaisir de vos papilles. accompgner cela avec du watafufu ou du tapioca",
    "Le poisson braisé est un plat typiquement consommé par le peuple  du Cameroun. Son goût délicieux l'a fait gagner en popularité dans d'autres parties du pays. L'ingrédient clé est *** intensément aromatique, accompagnée avec du bololo, miondo, frtit de plantain ou pommes et du manioc.",
    "se sont des oeufs accompagnées sur leurs de salades plein d'amoga3 et surtout redonne du punch dans le plaisir de revivre votre jeunesse,s'accompagne d'un pain bien chaud",
    "un jolie plat remplir de couleur aussi bon dans la bouche que beau pour les yeux. cette macédoine s'accompagne d'un pain bien chaud",
    "oh! ce café chaud que bon adourcir par un lait ontieux et crémeux qui n'attend que vous",
    "ce gateau très délicieux qui ne laisse personne indifférent sur monté d'une crème ontieuse et gouteuse",
    "et là un classique de la gastronomie fraise qui vous fera voyagez sans quitter votre chaise",
    "ici même la théorie du danger n'est pas applicable car tu seras toujours en danger, notre cockatils de fraise alcoolisée",
    "ce cocktail à la saveurs citron et menthes, faites à base de citron et d'un soupsçon de menthe  vous rendra aussi fraiches que radieuse",
  ];

  var imagesList = [
    "images/plat1.jpg",
    "images/plat2.jpg",
    "images/entrée1.jpg",
    "images/entrée2.jpg",
    "images/café.jpg",
    "images/dessert1.jpg",
    "images/dessert2.jpg",
    "images/boisson 1.jpg",
    "images/boisson2.jpg",
  ];
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width * 0.6;

    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios_new,
              color: Colors.white,
              size: 30,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
        ),
        backgroundColor: Colors.grey,
        body: ListView.builder(
          itemCount: imagesList.length,
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                showDialogFunc(context, imagesList[index], titleList[index],
                    descList[index]);
              },
              child: Card(
                  child: Row(
                children: <Widget>[
                  const SizedBox(
                    height: 10,
                  ),
                  SizedBox(
                    width: 100,
                    height: 100,
                    child: Image.asset(imagesList[index]),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          titleList[index].toUpperCase(),
                          style: const TextStyle(
                            fontSize: 22,
                            color: Colors.blue,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                      ],
                    ),
                  )
                ],
              )),
            );
          },
        ));
  }
}

showDialogFunc(context, images, title, desc) {
  return showDialog(
      context: context,
      builder: (context) {
        return Center(
          child: Material(
            type: MaterialType.transparency,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                color: Colors.white,
              ),
              padding: const EdgeInsets.all(20),
              width: MediaQuery.of(context).size.width * 0.8,
              height: 350,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 25,
                      color: Colors.blue,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Text(
                    desc,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 20,
                      color: Color.fromARGB(255, 35, 2, 54),
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      });
}
